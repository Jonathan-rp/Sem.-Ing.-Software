#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    TP = QSqlDatabase:: addDatabase("QSQLITE");
    QString ubicacion= ("TP.db");
    TP.setDatabaseName(ubicacion);
    TP.open();

    if(!TP.open()){
        qDebug()<<"No se abrio esta wea";
    }else{
        qDebug()<<"Si se abrió la base de Datos";
    }

    ui->SW->setCurrentIndex(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_Iniciar_clicked()
{
        ui->SW->setCurrentIndex(2);
}

void MainWindow::on_aceptar_PB_clicked()  // INICIAR SESIÓN //////////////////
{
    QMessageBox message;
    QString usuario, contrasena, query, name,rol,password,user;

    usuario = ui->usuario_LE->text();
    contrasena = ui->contrasena_LE->text();

     QSqlQuery qry;

     query.append("SELECT * FROM ADMIN WHERE USER = '"+usuario+"' AND PASSWORD = '"+contrasena+"'");
     qry.prepare(query);
     if(qry.exec()){
         qDebug()<<"Se ha consultado correctamente";
         qry.next();
         user = qry.value(0).toByteArray().constData();
         password = qry.value(1).toByteArray().constData();
         name = qry.value(3).toByteArray().constData();
         rol = qry.value(5).toByteArray().constData();

         if(user == usuario && password == contrasena){
         message.setText("WELCOME :)");
         message.exec();
         ui->SW->setCurrentIndex(1);
         ui->usuario_LE->setText("");
         ui->contrasena_LE->setText("");

         ui->NameUser->setText("WELCOME "+rol+" "+name);
         }else{
             message.setText("USER OR PASSWORD ARE INCORRECT :c");
             message.exec();
             ui->usuario_LE->setText("");
             ui->contrasena_LE->setText("");
         }
     }
     else{
         qDebug()<<"Unable to do the query";
         qDebug()<<"ERROR! "<<qry.lastError();
         ui->usuario_LE->setText("");
         ui->contrasena_LE->setText("");
     }

}

void MainWindow::on_cancelar_PB_clicked()
{
    exit(0);
}

void MainWindow::on_AddAgent_clicked()
{
    ui->SW->setCurrentIndex(3);
}

void MainWindow::on_Lista_act_clicked()
{
    ui->SW->setCurrentIndex(4);
    ui->eliminarAG->setVisible(false);
    ui->eliminarAG_2->setVisible(true);
    UncheckList();
    SetCheckList();
}

void MainWindow::on_VerLista_clicked()
{
    ui->SW->setCurrentIndex(5);
    ShowAgents();
}

void MainWindow::on_Gestionar_clicked()
{
    ui->SW->setCurrentIndex(6);
    verAg();
    ui->eliminarAG->setVisible(false);
}

void MainWindow::on_logOut_clicked()
{
    ui->SW->setCurrentIndex(0);
}

void MainWindow::on_backMenu_clicked()
{
    ui->SW->setCurrentIndex(2);
}

void MainWindow::on_backRP_4_clicked()
{
    ui->SW->setCurrentIndex(2);
}

void MainWindow::on_backVerMed_clicked()
{
    ui->SW->setCurrentIndex(2);
}

void MainWindow::on_back_m_clicked()
{
    ui->SW->setCurrentIndex(2);
    ui->eliminarAG->setVisible(false);
    ui->eliminarAG_2->setVisible(true);
}

void MainWindow::on_saveAG_clicked() //Guardar Agente////////////////////////
{
    QSqlQuery qry, qry2,qry3;
    //Insertar el Agente//////////////////////
        QString id = ui->LEID->text(),name = ui->namesAG_2->text(),lastname1 = ui->lastnameAG1->text(),
                lastname2 = ui->lastnameAG2->text(), sex = ui->sexAG->text(), dateOfbirth = ui->Fecha_nacAG_2->text(),
                curp = ui->curpAG_2->text(), rfc = ui->rfcAG_2->text(), address = ui->addressAG_2->text(),
                cel = ui->celAG_2->text(),agent;
        agent.append("INSERT INTO STAFF VALUES('"+id+"','"+name+"','"+lastname1+"','"+lastname2+"','"
                         +sex+"','"+dateOfbirth+"','"+curp+"','"+rfc+"','"+address+"','"+cel+"')");
        qry.prepare(agent);
        if(qry.exec()){
                       qDebug()<<"Se ha insertado corectamente.";
            }else{
                    qDebug()<<"No se ha insertado correctamente.";
                    qDebug()<<"ERROR! "<<qry.lastError();
                }
        //Insertar el Equipo//////////////////////
       QString SNCPU = ui->cpuSN_2->text(), SNMONITOR1 = ui->monitorSN_1->text(), SNMONITOR2 = ui->monitorSN_2->text(),
               CL_AMOUNT = ui->CA_AMOUNT->text(), equipment;
       equipment.append("INSERT INTO EQUIPMENT VALUES('"+id+"','"+SNCPU+"','"+SNMONITOR1+"','"
                        +SNMONITOR2+"','"+CL_AMOUNT+"')");
       qry2.prepare(equipment);
       if(qry2.exec()){
                      qDebug()<<"Se ha insertado corectamente.";
           }else{
                   qDebug()<<"No se ha insertado correctamente.";
                   qDebug()<<"ERROR! "<<qry2.lastError();
               }
       //Insertar lista de Actividades////////////////////////
       QString lista;
       lista.append("INSERT INTO LIST VALUES('"+id+"','1', '0','0','1','0','0')");
       qry3.prepare(lista);
       if(qry3.exec()){
                      qDebug()<<"Se ha insertado corectamente.";
           }else{
                   qDebug()<<"No se ha insertado correctamente.";
                   qDebug()<<"ERROR! "<<qry2.lastError();
               }
       clear_AddAgent();

}

void MainWindow::clear_AddAgent() //CLEANS THE CHARTS OF ADD AGENT AND EQUIPMENT
{
    //CLEAR ADD AGENT
    ui->LEID->setText("");
    ui->namesAG_2->setText("");
    ui->lastnameAG1->setText("");
    ui->lastnameAG2->setText("");
    ui->sexAG->setText("");
    ui->Fecha_nacAG_2->setText("");
    ui->curpAG_2->setText("");
    ui->rfcAG_2->setText("");
    ui->addressAG_2->setText("");
    ui->celAG_2->setText("");

    //CLEAR ADD EQUIPMENT
    ui->cpuSN_2->setText("");
    ui->monitorSN_1->setText("");
    ui->monitorSN_2->setText("");
    ui->CA_AMOUNT->setText("");
}


void MainWindow::on_CancelarADD_clicked() //CANCEL REGISTRATION OF AGENT OR ANY MODIFICATIONS
{
    clear_AddAgent();
    ui->UpdateAG->setEnabled(false);
    ui->LEID->setEnabled(true);
}
void MainWindow::on_SearchAG_2_textChanged(const QString &arg1) // Unlock the search button
{
    Q_UNUSED(arg1);
    if(ui->SearchAG_2->text().length() > 0){
    ui->SearchAG_3->setEnabled(true);
    }
}

void MainWindow::ShowAgents() // Show the AGENTS ON SHOW AGENTS
{
    ui->verAgents->clearContents();
    QSqlQuery qry;
    QString consulta;
    consulta.append("SELECT * FROM STAFF");
    qry.prepare(consulta);

    if(qry.exec()){
           qDebug()<<"Se ha consultado correctamente.";
}else{
        qDebug()<<"No se ha consultado correctamente.";
        qDebug()<<"ERROR! "<<qry.lastError();
    }

    int fila = 0;
    ui->verAgents->setRowCount(0);
    while(qry.next()){
        ui->verAgents->insertRow(fila);
        ui->verAgents->setItem(fila,0,new QTableWidgetItem(qry.value(1).toByteArray().constData()));
        ui->verAgents->setItem(fila,1,new QTableWidgetItem(qry.value(2).toByteArray().constData()));
        ui->verAgents->setItem(fila,2,new QTableWidgetItem(qry.value(3).toByteArray().constData()));
        ui->verAgents->setItem(fila,3,new QTableWidgetItem(qry.value(5).toByteArray().constData()));
        ui->verAgents->setItem(fila,4,new QTableWidgetItem(qry.value(6).toByteArray().constData()));
        ui->verAgents->setItem(fila,5,new QTableWidgetItem(qry.value(7).toByteArray().constData()));
        ui->verAgents->setItem(fila,6,new QTableWidgetItem(qry.value(8).toByteArray().constData()));
        ui->verAgents->setItem(fila,7,new QTableWidgetItem(qry.value(9).toByteArray().constData()));
        fila++;
    }
}

void MainWindow::verAg() //Show the Agents on WAHA MANAGEMENT
{
    ui->verAG->clearContents();
    QSqlQuery qry;
    QString consulta;
    consulta.append("SELECT * FROM STAFF");
    qry.prepare(consulta);

    if(qry.exec()){
           qDebug()<<"Se ha consultado correctamente.";
}else{
        qDebug()<<"No se ha consultado correctamente.";
        qDebug()<<"ERROR! "<<qry.lastError();
    }

    int fila = 0;
    ui->verAG->setRowCount(0);
    while(qry.next()){
        ui->verAG->insertRow(fila);
        ui->verAG->setItem(fila,0,new QTableWidgetItem(qry.value(0).toByteArray().constData()));
        ui->verAG->setItem(fila,1,new QTableWidgetItem(qry.value(1).toByteArray().constData()));
        ui->verAG->setItem(fila,2,new QTableWidgetItem(qry.value(2).toByteArray().constData()));
        ui->verAG->setItem(fila,3,new QTableWidgetItem(qry.value(3).toByteArray().constData()));
        ui->verAG->setItem(fila,4,new QTableWidgetItem(qry.value(5).toByteArray().constData()));
        ui->verAG->setItem(fila,5,new QTableWidgetItem(qry.value(6).toByteArray().constData()));
        ui->verAG->setItem(fila,6,new QTableWidgetItem(qry.value(7).toByteArray().constData()));
        ui->verAG->setItem(fila,7,new QTableWidgetItem(qry.value(8).toByteArray().constData()));
        ui->verAG->setItem(fila,8,new QTableWidgetItem(qry.value(9).toByteArray().constData()));
        fila++;
    }
}

void MainWindow::SearchAgent(QString id) // SEARCH FOR ANY AGENT
{
    QSqlQuery qry; Staff s;
    QString search;
    search.append("select * from STAFF where ID = "+id);
    qry.prepare(search);

    if(qry.exec()){
           qDebug()<<"Se ha consultado correctamente.";
}else{
        qDebug()<<"No se ha consultado correctamente.";
        qDebug()<<"ERROR! "<<qry.lastError();
    }
    qry.next(); //SETTEAR EL OBJETO DE TIPO STAFF PARA MEJOR ORDEN
    s.setId(id);
    s.setName(qry.value(1).toByteArray().constData());
    s.setF_name(qry.value(2).toByteArray().constData());
    s.setL_name(qry.value(3).toByteArray().constData());
    s.setGender(qry.value(4).toByteArray().constData());
    s.setDate_birth(qry.value(5).toByteArray().constData());
    s.setCurp(qry.value(6).toByteArray().constData());
    s.setRfc(qry.value(7).toByteArray().constData());
    s.setAddress(qry.value(8).toByteArray().constData());
    s.setPhone(qry.value(9).toByteArray().constData());
    SetAgent(s); // se manda a setear en los charts
    SearchEquipment(id);  //Se busca el equipo que tiene el Agente
}

void MainWindow::SetAgent(Staff s) // SET INFO OF THE AGENT IN THE CHARTS
{
    ui->LEID->setText(s.getId());
    ui->LEID->setEnabled(false);
    ui->namesAG_2->setText(s.getName());
    ui->lastnameAG1->setText(s.getF_name());
    ui->lastnameAG2->setText(s.getL_name());
    ui->sexAG->setText(s.getGender());
    ui->Fecha_nacAG_2->setText(s.getDate_birth());
    ui->curpAG_2->setText(s.getCurp());
    ui->rfcAG_2->setText(s.getRfc());
    ui->addressAG_2->setText(s.getAddress());
    ui->celAG_2->setText(s.getPhone());
}

void MainWindow::SearchEquipment(QString id) //SEARCH FOR THE EQUIPMENT OF AN AGENT
{
    QSqlQuery qry; Equipment e;
    QString search;
    search.append("select * from EQUIPMENT where ID = "+id);
    qry.prepare(search);

    if(qry.exec()){
           qDebug()<<"Se ha consultado correctamente.";
}else{
        qDebug()<<"No se ha consultado correctamente.";
        qDebug()<<"ERROR! "<<qry.lastError();
    }
    qry.next(); //SETTEAR EL OBJETO DE TIPO EQUIPMENT PARA MEJOR ORDEN
    e.setId(id);
    e.setSncpu(qry.value(1).toByteArray().constData());
    e.setSnmonitor1(qry.value(2).toByteArray().constData());
    e.setSnmonitor2(qry.value(3).toByteArray().constData());
    e.setCables_amount(qry.value(4).toByteArray().constData());
    SetEquipment(e); // se manda a setear en los charts
}

void MainWindow::SetEquipment(Equipment e)
{
    ui->cpuSN_2->setText(e.getSncpu());
    ui->monitorSN_1->setText(e.getSnmonitor1());
    ui->monitorSN_2->setText(e.getSnmonitor2());
    ui->CA_AMOUNT->setText(e.getCables_amount());
}

void MainWindow::ModAgent()
{
    QSqlQuery qry, qry2,qry3;
    //Modificar el Agente//////////////////////
        QString id = ui->LEID->text(),name = ui->namesAG_2->text(),lastname1 = ui->lastnameAG1->text(),
                lastname2 = ui->lastnameAG2->text(), sex = ui->sexAG->text(), dateOfbirth = ui->Fecha_nacAG_2->text(),
                curp = ui->curpAG_2->text(), rfc = ui->rfcAG_2->text(), address = ui->addressAG_2->text(),
                cel = ui->celAG_2->text(),agent;
        agent.append("UPDATE STAFF SET NAME ='"+name+"',F_NAME ='"+lastname1+"',L_NAME ='"+lastname2+"',GENDER = '"
                         +sex+"',DATE_BIRTH = '"+dateOfbirth+"', CURP ='"+curp+"',RFC='"+rfc+"',ADDRESS ='"+address+"',PHONE='"+cel+"' WHERE ID = '"+id+"'");
        qry.prepare(agent);
        if(qry.exec()){
                       qDebug()<<"Se ha insertado corectamente.";
            }else{
                    qDebug()<<"No se ha insertado correctamente.";
                    qDebug()<<"ERROR! "<<qry.lastError();
                }
        //Modificar el Equipo//////////////////////
       QString SNCPU = ui->cpuSN_2->text(), SNMONITOR1 = ui->monitorSN_1->text(), SNMONITOR2 = ui->monitorSN_2->text(),
               CL_AMOUNT = ui->CA_AMOUNT->text(), equipment;
       equipment.append("UPDATE INTO EQUIPMENT SET SNCPU = '"+SNCPU+"',SNMONITOR1 ='"+SNMONITOR1+"', SNMONITOR2 ='"
                        +SNMONITOR2+"',CABLES_AMOUNT ='"+CL_AMOUNT+"' WHERE ID = '"+id+"'");
       qry2.prepare(equipment);
       if(qry2.exec()){
                      qDebug()<<"Se ha insertado corectamente.";
           }else{
                   qDebug()<<"No se ha insertado correctamente.";
                   qDebug()<<"ERROR! "<<qry2.lastError();
               }

       clear_AddAgent();
}

void MainWindow::DelAgent() //Elimina el Agente
{
     QString delAgent, delEquipment, delList;
     QSqlQuery qry, qry2,qry3;
     //Deleting Agent
     delAgent.append("DELETE FROM STAFF WHERE ID ='"+idStaff+"'");
     qry.prepare(delAgent);
     if(qry.exec()){
                    qDebug()<<"Se ha insertado corectamente.";
         }else{
                 qDebug()<<"No se ha insertado correctamente.";
                 qDebug()<<"ERROR! "<<qry.lastError();
             }
     //Deletin Equipment
     delEquipment.append("DELETE FROM EQUIPMENT WHERE ID ='"+idStaff+"'");
     qry2.prepare(delEquipment);
     if(qry2.exec()){
                    qDebug()<<"Se ha insertado corectamente.";
         }else{
                 qDebug()<<"No se ha insertado correctamente.";
                 qDebug()<<"ERROR! "<<qry2.lastError();
             }
     //Deleting List
     delList.append("DELETE FROM LIST WHERE ID ='"+idStaff+"'");
     qry3.prepare(delList);
     if(qry3.exec()){
                    qDebug()<<"Se ha insertado corectamente.";
         }else{
                 qDebug()<<"No se ha insertado correctamente.";
                 qDebug()<<"ERROR! "<<qry3.lastError();
     }
}

void MainWindow::UncheckList()
{
    ui->checkData->setChecked(false);
    ui->checkEntrega->setChecked(false);
    ui->checkFirmar->setChecked(false);
    ui->checkEquipo->setChecked(false);
    ui->checkPerfil->setChecked(false);
    ui->checkExtensiones->setChecked(false);
}

void MainWindow::SetCheckList() //Settea la lista del agente seleccionado
{
    QSqlQuery qry;
    QString datos, entrega, firmar, equipo, perfil, extensiones, consulta;

    consulta.append("SELECT * FROM LIST WHERE ID ="+idStaff);
    qry.prepare(consulta);
    if(qry.exec()){
                   qDebug()<<"Se ha consultado corectamente.";
        }else{
                qDebug()<<"No se ha consultado correctamente.";
                qDebug()<<"ERROR! "<<qry.lastError();
    }

    qry.next();
    datos = qry.value(1).toByteArray().constData();
    entrega = qry.value(2).toByteArray().constData();
    firmar = qry.value(3).toByteArray().constData();
    equipo = qry.value(4).toByteArray().constData();
    perfil = qry.value(5).toByteArray().constData();
    extensiones = qry.value(6).toByteArray().constData();

    if(datos == '1'){
        ui->checkData->setChecked(true);
    }
    if(entrega == '1'){
        ui->checkEntrega->setChecked(true);
    }
    if(firmar == '1'){
        ui->checkFirmar->setChecked(true);
    }
    if(equipo == '1'){
        ui->checkEquipo->setChecked(true);
    }
    if(perfil == '1'){
        ui->checkPerfil->setChecked(true);
    }if(extensiones == '1'){
        ui->checkExtensiones->setChecked(true);
    }
}

void MainWindow::SavedCheckList()
{
    QSqlQuery qry;
    QString datos, entrega, firmar, equipo, perfil, extensiones, consulta;

    if(ui->checkData->isChecked()){
        datos = '1';
    }else{
        datos = '0';
    }
    if(ui->checkEntrega->isChecked()){
        entrega = '1';
    }else{
        entrega = '0';
    }
    if(ui->checkFirmar->isChecked()){
        firmar = '1';
    }else{
        firmar = '0';
    }
    if(ui->checkEquipo->isChecked()){
        equipo = '1';
    }else{
        equipo = '0';
    }
    if(ui->checkPerfil->isChecked()){
       perfil = '1';
    }else{
        perfil = '0';
    }if(ui->checkExtensiones->isChecked()){
        extensiones = '1';
    }else{
        extensiones = '0';
    }


    consulta.append("UPDATE LIST SET DATOS='"+datos+"',ENTREGA = '"+entrega+"',FIRMAR ='"+firmar+
                    "', EQUIPO ='"+equipo+"', PERFIL = '"+perfil+"',EXTENSIONES = '"+extensiones+"' WHERE ID ="+idStaff);
    qry.prepare(consulta);
    if(qry.exec()){
                   qDebug()<<"Se ha consultado corectamente.";
        }else{
                qDebug()<<"No se ha consultado correctamente.";
                qDebug()<<"ERROR! "<<qry.lastError();
    }
}

void MainWindow::on_SearchAG_3_clicked() // CLICK ON SEARCH BUTTON
{
    SearchAgent(ui->SearchAG_2->text());
    ui->SearchAG_2->setText("");
    ui->SearchAG_3->setEnabled(false);
}

void MainWindow::on_verAG_itemSelectionChanged() // SELECTION ANY ITEM ON AGENTS TABLE
{
    int row = ui->verAG->currentRow();
    QTableWidgetItem idRow = *ui->verAG->item(row,0);
      idStaff = idRow.text();
}

void MainWindow::on_update_AG_clicked() // MODIFY ANY AGENT
{
    ui->SW->setCurrentIndex(3);
    SearchAgent(idStaff);
    ui->UpdateAG->setEnabled(true);
    ui->eliminarAG->setVisible(false);
    ui->eliminarAG_2->setVisible(true);
}

void MainWindow::on_addAG_clicked() //GO TO ADD A NEW AGENT
{
     ui->SW->setCurrentIndex(3);
     ui->eliminarAG->setVisible(false);
     ui->eliminarAG_2->setVisible(true);
}

void MainWindow::on_UpdateAG_clicked() //MODIFY THE AGENT WITH THIS BUTTON
{
    ModAgent();
    clear_AddAgent();
    ui->UpdateAG->setEnabled(false);
}

void MainWindow::on_eliminarAG_clicked() //BUTTON TO DELETE THE RECORD
{
      DelAgent();
      QMessageBox message;
      message.setText("REGISTRO ELIMINADO");
      message.exec();
      verAg();
      ui->eliminarAG->setVisible(false);
      ui->eliminarAG_2->setVisible(true);
}

void MainWindow::on_eliminarAG_2_clicked() //ASKS IF REALLY WANT TO DELETE THE AGENT OF THE SYSTEM
{
    QMessageBox message;
    message.setText("SI QUIERES ELIMINAR ESTE REGISTRO DE MANERA DEFINITIVA, VUELVE A PRESIONAR EL BOTÓN DE BORRADO");
    message.exec();
    ui->eliminarAG_2->setVisible(false);
    ui->eliminarAG->setVisible(true);
}

void MainWindow::on_saveCh_clicked() //Save data checkboxes
{
    SavedCheckList();
    UncheckList();
    SetCheckList();
}
