#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>
#include <QtSql>
#include <QtDebug>
#include <QFileInfo>
#include <QString>
#include <windows.h>
#include <stdio.h>
#include <QMessageBox>
#include <iostream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include "staff.h"
#include "equipment.h"

using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_Iniciar_clicked();

    void on_aceptar_PB_clicked();

    void on_cancelar_PB_clicked();

    void on_AddAgent_clicked();

    void on_Lista_act_clicked();

    void on_VerLista_clicked();

    void on_Gestionar_clicked();

    void on_logOut_clicked();

    void on_backMenu_clicked();

    void on_backRP_4_clicked();

    void on_backVerMed_clicked();

    void on_back_m_clicked();

    void on_saveAG_clicked();

    void on_CancelarADD_clicked();

    void on_SearchAG_2_textChanged(const QString &arg1);

    void on_SearchAG_3_clicked();

    void on_verAG_itemSelectionChanged();

    void on_update_AG_clicked();

    void on_addAG_clicked();

    void on_UpdateAG_clicked();

    void on_eliminarAG_clicked();

    void on_eliminarAG_2_clicked();

    void on_saveCh_clicked();

private:
    Ui::MainWindow *ui;
    QSqlDatabase TP;
    void clear_AddAgent();
    void ShowAgents();
    void verAg();
    void DelAgent(QString id);
    void SearchAgent(QString id);
    void SetAgent(Staff s);
    void SearchEquipment(QString id);
    void SetEquipment(Equipment e);
    void ModAgent();
    void DelAgent();
    void UncheckList();
    void SetCheckList();
    void SavedCheckList();
    QString idStaff;
};
#endif // MAINWINDOW_H
