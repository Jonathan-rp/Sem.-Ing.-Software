#include "equipment.h"

Equipment::Equipment()
{

}

QString Equipment::getId() const
{
    return id;
}

void Equipment::setId(const QString &value)
{
    id = value;
}

QString Equipment::getSncpu() const
{
    return sncpu;
}

void Equipment::setSncpu(const QString &value)
{
    sncpu = value;
}

QString Equipment::getSnmonitor1() const
{
    return snmonitor1;
}

void Equipment::setSnmonitor1(const QString &value)
{
    snmonitor1 = value;
}

QString Equipment::getSnmonitor2() const
{
    return snmonitor2;
}

void Equipment::setSnmonitor2(const QString &value)
{
    snmonitor2 = value;
}

QString Equipment::getCables_amount() const
{
    return cables_amount;
}

void Equipment::setCables_amount(const QString &value)
{
    cables_amount = value;
}
