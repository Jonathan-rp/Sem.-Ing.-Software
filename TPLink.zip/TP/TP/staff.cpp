#include "staff.h"

Staff::Staff()
{

}

QString Staff::getId() const
{
    return id;
}

void Staff::setId(const QString &value)
{
    id = value;
}

QString Staff::getF_name() const
{
    return f_name;
}

void Staff::setF_name(const QString &value)
{
    f_name = value;
}

QString Staff::getL_name() const
{
    return l_name;
}

void Staff::setL_name(const QString &value)
{
    l_name = value;
}

QString Staff::getGender() const
{
    return gender;
}

void Staff::setGender(const QString &value)
{
    gender = value;
}

QString Staff::getDate_birth() const
{
    return date_birth;
}

void Staff::setDate_birth(const QString &value)
{
    date_birth = value;
}

QString Staff::getCurp() const
{
    return curp;
}

void Staff::setCurp(const QString &value)
{
    curp = value;
}

QString Staff::getRfc() const
{
    return rfc;
}

void Staff::setRfc(const QString &value)
{
    rfc = value;
}

QString Staff::getAddress() const
{
    return address;
}

void Staff::setAddress(const QString &value)
{
    address = value;
}

QString Staff::getPhone() const
{
    return phone;
}

void Staff::setPhone(const QString &value)
{
    phone = value;
}

QString Staff::getName() const
{
    return name;
}

void Staff::setName(const QString &value)
{
    name = value;
}
