#ifndef STAFF_H
#define STAFF_H
#include <iostream>
#include <QString>

using namespace std;

class Staff
{
public:
    Staff();

    QString getId() const;
    void setId(const QString &value);

    QString getF_name() const;
    void setF_name(const QString &value);

    QString getL_name() const;
    void setL_name(const QString &value);

    QString getGender() const;
    void setGender(const QString &value);

    QString getDate_birth() const;
    void setDate_birth(const QString &value);

    QString getCurp() const;
    void setCurp(const QString &value);

    QString getRfc() const;
    void setRfc(const QString &value);

    QString getAddress() const;
    void setAddress(const QString &value);

    QString getPhone() const;
    void setPhone(const QString &value);

    QString getName() const;
    void setName(const QString &value);

private:
    QString id;
    QString name;
    QString f_name;
    QString l_name;
    QString gender;
    QString date_birth;
    QString curp;
    QString rfc;
    QString address;
    QString phone;

};

#endif // STAFF_H
