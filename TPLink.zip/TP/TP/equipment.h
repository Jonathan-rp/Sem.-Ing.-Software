#ifndef EQUIPMENT_H
#define EQUIPMENT_H
#include <iostream>
#include <QString>

using namespace std;

class Equipment
{
public:
    Equipment();

    QString getId() const;
    void setId(const QString &value);

    QString getSncpu() const;
    void setSncpu(const QString &value);

    QString getSnmonitor1() const;
    void setSnmonitor1(const QString &value);

    QString getSnmonitor2() const;
    void setSnmonitor2(const QString &value);

    QString getCables_amount() const;
    void setCables_amount(const QString &value);

private:
    QString id;
    QString sncpu;
    QString snmonitor1;
    QString snmonitor2;
    QString cables_amount;
};

#endif // EQUIPMENT_H
