/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QStackedWidget *SW;
    QWidget *page_0;
    QGridLayout *gridLayout_3;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QPushButton *aceptar_PB;
    QLabel *usuario_LB;
    QLineEdit *usuario_LE;
    QLabel *contrasena_LB;
    QLineEdit *contrasena_LE;
    QPushButton *cancelar_PB;
    QWidget *home_1;
    QGridLayout *gridLayout1;
    QLabel *label_4;
    QPushButton *Iniciar;
    QLabel *title;
    QLabel *NameUser;
    QWidget *Menu;
    QPushButton *AddAgent;
    QPushButton *VerLista;
    QPushButton *logOut;
    QLabel *img_2;
    QLabel *title_5;
    QPushButton *Gestionar;
    QWidget *AddAgente;
    QLabel *namesAG;
    QLabel *lastnameAG;
    QLabel *sexAG_2;
    QLabel *Fecha_nacAG;
    QLabel *curpAG;
    QLabel *rfcAG;
    QLabel *addressAG;
    QLabel *celAG;
    QLineEdit *namesAG_2;
    QLineEdit *lastnameAG1;
    QLineEdit *sexAG;
    QLineEdit *Fecha_nacAG_2;
    QLineEdit *curpAG_2;
    QLineEdit *rfcAG_2;
    QLineEdit *addressAG_2;
    QLineEdit *celAG_2;
    QLabel *hiredDL;
    QPushButton *saveAG;
    QPushButton *backMenu;
    QLineEdit *lastnameAG2;
    QLabel *title_6;
    QPushButton *UpdateAG;
    QPushButton *CancelarADD;
    QLabel *SearchAG;
    QLineEdit *SearchAG_2;
    QPushButton *SearchAG_3;
    QLineEdit *monitorSN_1;
    QLineEdit *cpuSN_2;
    QLabel *monitorSN;
    QLabel *cpuSN;
    QLabel *CableRedCB;
    QLineEdit *monitorSN_2;
    QLabel *lbmonitor1;
    QLabel *lbmonitor2;
    QLineEdit *CA_AMOUNT;
    QLabel *lbid;
    QLineEdit *LEID;
    QWidget *ListaACT;
    QLabel *title_16;
    QPushButton *backRP_4;
    QLineEdit *lineEdit;
    QCheckBox *checkData;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QCheckBox *checkFirmar;
    QCheckBox *checkEquipo;
    QCheckBox *checkPerfil;
    QCheckBox *checkExtensiones;
    QCheckBox *checkEntrega;
    QPushButton *saveCh;
    QWidget *VerAG;
    QLabel *title_17;
    QTableWidget *verAgents;
    QPushButton *backVerMed;
    QWidget *GestionarAG;
    QTableWidget *verAG;
    QLabel *title_18;
    QPushButton *update_AG;
    QPushButton *back_m;
    QPushButton *addAG;
    QPushButton *eliminarAG;
    QPushButton *Lista_act;
    QPushButton *eliminarAG_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        SW = new QStackedWidget(centralwidget);
        SW->setObjectName(QString::fromUtf8("SW"));
        SW->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(255, 255, 255);"));
        page_0 = new QWidget();
        page_0->setObjectName(QString::fromUtf8("page_0"));
        gridLayout_3 = new QGridLayout(page_0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        groupBox = new QGroupBox(page_0);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        aceptar_PB = new QPushButton(groupBox);
        aceptar_PB->setObjectName(QString::fromUtf8("aceptar_PB"));
        aceptar_PB->setSizeIncrement(QSize(0, 0));
        aceptar_PB->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(62,95,138);\n"
"color:rgb(255,255,255);\n"
"}"));

        gridLayout_2->addWidget(aceptar_PB, 2, 1, 1, 1);

        usuario_LB = new QLabel(groupBox);
        usuario_LB->setObjectName(QString::fromUtf8("usuario_LB"));

        gridLayout_2->addWidget(usuario_LB, 0, 0, 1, 1);

        usuario_LE = new QLineEdit(groupBox);
        usuario_LE->setObjectName(QString::fromUtf8("usuario_LE"));

        gridLayout_2->addWidget(usuario_LE, 0, 1, 1, 1);

        contrasena_LB = new QLabel(groupBox);
        contrasena_LB->setObjectName(QString::fromUtf8("contrasena_LB"));

        gridLayout_2->addWidget(contrasena_LB, 1, 0, 1, 1);

        contrasena_LE = new QLineEdit(groupBox);
        contrasena_LE->setObjectName(QString::fromUtf8("contrasena_LE"));
        contrasena_LE->setEchoMode(QLineEdit::Password);

        gridLayout_2->addWidget(contrasena_LE, 1, 1, 1, 1);

        cancelar_PB = new QPushButton(groupBox);
        cancelar_PB->setObjectName(QString::fromUtf8("cancelar_PB"));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        font.setKerning(true);
        font.setStyleStrategy(QFont::PreferDefault);
        cancelar_PB->setFont(font);
        cancelar_PB->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"border-color: rgb(0, 0, 127);\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));

        gridLayout_2->addWidget(cancelar_PB, 3, 1, 1, 1);


        gridLayout_3->addWidget(groupBox, 0, 0, 1, 1);

        SW->addWidget(page_0);
        home_1 = new QWidget();
        home_1->setObjectName(QString::fromUtf8("home_1"));
        gridLayout1 = new QGridLayout(home_1);
        gridLayout1->setObjectName(QString::fromUtf8("gridLayout1"));
        label_4 = new QLabel(home_1);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/imc/Tp")));

        gridLayout1->addWidget(label_4, 0, 1, 1, 1);

        Iniciar = new QPushButton(home_1);
        Iniciar->setObjectName(QString::fromUtf8("Iniciar"));
        Iniciar->setMinimumSize(QSize(233, 28));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Trebuchet MS"));
        font1.setPointSize(9);
        font1.setBold(true);
        font1.setWeight(75);
        Iniciar->setFont(font1);

        gridLayout1->addWidget(Iniciar, 4, 1, 1, 1);

        title = new QLabel(home_1);
        title->setObjectName(QString::fromUtf8("title"));
        title->setScaledContents(true);

        gridLayout1->addWidget(title, 2, 1, 1, 1);

        NameUser = new QLabel(home_1);
        NameUser->setObjectName(QString::fromUtf8("NameUser"));

        gridLayout1->addWidget(NameUser, 3, 1, 1, 1);

        SW->addWidget(home_1);
        Menu = new QWidget();
        Menu->setObjectName(QString::fromUtf8("Menu"));
        AddAgent = new QPushButton(Menu);
        AddAgent->setObjectName(QString::fromUtf8("AddAgent"));
        AddAgent->setGeometry(QRect(100, 460, 151, 41));
        AddAgent->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(62,95,138);\n"
"color:rgb(255,255,255);\n"
"}"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/imgs/doc.png"), QSize(), QIcon::Normal, QIcon::On);
        AddAgent->setIcon(icon);
        VerLista = new QPushButton(Menu);
        VerLista->setObjectName(QString::fromUtf8("VerLista"));
        VerLista->setGeometry(QRect(50, 80, 291, 31));
        VerLista->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(62,95,138);\n"
"color:rgb(255,255,255);\n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/imgs/agenda.png"), QSize(), QIcon::Normal, QIcon::On);
        VerLista->setIcon(icon1);
        logOut = new QPushButton(Menu);
        logOut->setObjectName(QString::fromUtf8("logOut"));
        logOut->setGeometry(QRect(550, 80, 141, 31));
        logOut->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/imgs/log out.png"), QSize(), QIcon::Normal, QIcon::On);
        logOut->setIcon(icon2);
        img_2 = new QLabel(Menu);
        img_2->setObjectName(QString::fromUtf8("img_2"));
        img_2->setGeometry(QRect(50, 140, 661, 281));
        img_2->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/imc/tp2.jpeg")));
        img_2->setScaledContents(true);
        title_5 = new QLabel(Menu);
        title_5->setObjectName(QString::fromUtf8("title_5"));
        title_5->setGeometry(QRect(280, 0, 181, 41));
        Gestionar = new QPushButton(Menu);
        Gestionar->setObjectName(QString::fromUtf8("Gestionar"));
        Gestionar->setGeometry(QRect(510, 460, 151, 41));
        Gestionar->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(62,95,138);\n"
"color:rgb(255,255,255);\n"
"}"));
        Gestionar->setIcon(icon);
        SW->addWidget(Menu);
        AddAgente = new QWidget();
        AddAgente->setObjectName(QString::fromUtf8("AddAgente"));
        namesAG = new QLabel(AddAgente);
        namesAG->setObjectName(QString::fromUtf8("namesAG"));
        namesAG->setGeometry(QRect(20, 50, 61, 16));
        lastnameAG = new QLabel(AddAgente);
        lastnameAG->setObjectName(QString::fromUtf8("lastnameAG"));
        lastnameAG->setGeometry(QRect(20, 80, 47, 14));
        sexAG_2 = new QLabel(AddAgente);
        sexAG_2->setObjectName(QString::fromUtf8("sexAG_2"));
        sexAG_2->setGeometry(QRect(20, 110, 47, 14));
        Fecha_nacAG = new QLabel(AddAgente);
        Fecha_nacAG->setObjectName(QString::fromUtf8("Fecha_nacAG"));
        Fecha_nacAG->setGeometry(QRect(20, 140, 111, 16));
        curpAG = new QLabel(AddAgente);
        curpAG->setObjectName(QString::fromUtf8("curpAG"));
        curpAG->setGeometry(QRect(20, 170, 47, 14));
        rfcAG = new QLabel(AddAgente);
        rfcAG->setObjectName(QString::fromUtf8("rfcAG"));
        rfcAG->setGeometry(QRect(20, 200, 47, 20));
        addressAG = new QLabel(AddAgente);
        addressAG->setObjectName(QString::fromUtf8("addressAG"));
        addressAG->setGeometry(QRect(20, 230, 51, 16));
        celAG = new QLabel(AddAgente);
        celAG->setObjectName(QString::fromUtf8("celAG"));
        celAG->setGeometry(QRect(20, 260, 101, 16));
        namesAG_2 = new QLineEdit(AddAgente);
        namesAG_2->setObjectName(QString::fromUtf8("namesAG_2"));
        namesAG_2->setGeometry(QRect(140, 50, 271, 20));
        lastnameAG1 = new QLineEdit(AddAgente);
        lastnameAG1->setObjectName(QString::fromUtf8("lastnameAG1"));
        lastnameAG1->setGeometry(QRect(140, 80, 121, 20));
        sexAG = new QLineEdit(AddAgente);
        sexAG->setObjectName(QString::fromUtf8("sexAG"));
        sexAG->setGeometry(QRect(140, 110, 271, 20));
        Fecha_nacAG_2 = new QLineEdit(AddAgente);
        Fecha_nacAG_2->setObjectName(QString::fromUtf8("Fecha_nacAG_2"));
        Fecha_nacAG_2->setGeometry(QRect(140, 140, 271, 20));
        curpAG_2 = new QLineEdit(AddAgente);
        curpAG_2->setObjectName(QString::fromUtf8("curpAG_2"));
        curpAG_2->setGeometry(QRect(140, 170, 271, 20));
        rfcAG_2 = new QLineEdit(AddAgente);
        rfcAG_2->setObjectName(QString::fromUtf8("rfcAG_2"));
        rfcAG_2->setGeometry(QRect(140, 200, 271, 20));
        addressAG_2 = new QLineEdit(AddAgente);
        addressAG_2->setObjectName(QString::fromUtf8("addressAG_2"));
        addressAG_2->setGeometry(QRect(140, 230, 271, 20));
        celAG_2 = new QLineEdit(AddAgente);
        celAG_2->setObjectName(QString::fromUtf8("celAG_2"));
        celAG_2->setGeometry(QRect(140, 260, 271, 20));
        hiredDL = new QLabel(AddAgente);
        hiredDL->setObjectName(QString::fromUtf8("hiredDL"));
        hiredDL->setGeometry(QRect(120, 320, 111, 31));
        QFont font2;
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setWeight(75);
        hiredDL->setFont(font2);
        saveAG = new QPushButton(AddAgente);
        saveAG->setObjectName(QString::fromUtf8("saveAG"));
        saveAG->setEnabled(true);
        saveAG->setGeometry(QRect(10, 460, 221, 51));
        saveAG->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(62,95,138);\n"
"color:rgb(255,255,255);\n"
"}"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/imgs/save.ico"), QSize(), QIcon::Normal, QIcon::On);
        saveAG->setIcon(icon3);
        backMenu = new QPushButton(AddAgente);
        backMenu->setObjectName(QString::fromUtf8("backMenu"));
        backMenu->setGeometry(QRect(610, 20, 91, 41));
        backMenu->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/imgs/back.png"), QSize(), QIcon::Normal, QIcon::On);
        backMenu->setIcon(icon4);
        lastnameAG2 = new QLineEdit(AddAgente);
        lastnameAG2->setObjectName(QString::fromUtf8("lastnameAG2"));
        lastnameAG2->setGeometry(QRect(280, 80, 131, 20));
        title_6 = new QLabel(AddAgente);
        title_6->setObjectName(QString::fromUtf8("title_6"));
        title_6->setGeometry(QRect(170, 0, 361, 42));
        UpdateAG = new QPushButton(AddAgente);
        UpdateAG->setObjectName(QString::fromUtf8("UpdateAG"));
        UpdateAG->setEnabled(false);
        UpdateAG->setGeometry(QRect(270, 460, 211, 51));
        UpdateAG->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(62,95,138);\n"
"color:rgb(255,255,255);\n"
"}"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/imgs/update.png"), QSize(), QIcon::Normal, QIcon::On);
        UpdateAG->setIcon(icon5);
        UpdateAG->setIconSize(QSize(20, 20));
        CancelarADD = new QPushButton(AddAgente);
        CancelarADD->setObjectName(QString::fromUtf8("CancelarADD"));
        CancelarADD->setEnabled(true);
        CancelarADD->setGeometry(QRect(510, 460, 201, 51));
        CancelarADD->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/imgs/cancel.png"), QSize(), QIcon::Normal, QIcon::On);
        CancelarADD->setIcon(icon6);
        CancelarADD->setIconSize(QSize(20, 20));
        SearchAG = new QLabel(AddAgente);
        SearchAG->setObjectName(QString::fromUtf8("SearchAG"));
        SearchAG->setGeometry(QRect(560, 80, 81, 16));
        SearchAG_2 = new QLineEdit(AddAgente);
        SearchAG_2->setObjectName(QString::fromUtf8("SearchAG_2"));
        SearchAG_2->setGeometry(QRect(490, 100, 241, 20));
        SearchAG_3 = new QPushButton(AddAgente);
        SearchAG_3->setObjectName(QString::fromUtf8("SearchAG_3"));
        SearchAG_3->setEnabled(false);
        SearchAG_3->setGeometry(QRect(570, 130, 75, 23));
        monitorSN_1 = new QLineEdit(AddAgente);
        monitorSN_1->setObjectName(QString::fromUtf8("monitorSN_1"));
        monitorSN_1->setGeometry(QRect(210, 390, 171, 20));
        cpuSN_2 = new QLineEdit(AddAgente);
        cpuSN_2->setObjectName(QString::fromUtf8("cpuSN_2"));
        cpuSN_2->setGeometry(QRect(210, 360, 271, 20));
        monitorSN = new QLabel(AddAgente);
        monitorSN->setObjectName(QString::fromUtf8("monitorSN"));
        monitorSN->setGeometry(QRect(20, 390, 161, 16));
        cpuSN = new QLabel(AddAgente);
        cpuSN->setObjectName(QString::fromUtf8("cpuSN"));
        cpuSN->setGeometry(QRect(20, 360, 151, 16));
        CableRedCB = new QLabel(AddAgente);
        CableRedCB->setObjectName(QString::fromUtf8("CableRedCB"));
        CableRedCB->setGeometry(QRect(20, 420, 101, 16));
        monitorSN_2 = new QLineEdit(AddAgente);
        monitorSN_2->setObjectName(QString::fromUtf8("monitorSN_2"));
        monitorSN_2->setGeometry(QRect(420, 390, 171, 20));
        lbmonitor1 = new QLabel(AddAgente);
        lbmonitor1->setObjectName(QString::fromUtf8("lbmonitor1"));
        lbmonitor1->setGeometry(QRect(180, 390, 16, 16));
        lbmonitor2 = new QLabel(AddAgente);
        lbmonitor2->setObjectName(QString::fromUtf8("lbmonitor2"));
        lbmonitor2->setGeometry(QRect(390, 390, 16, 16));
        CA_AMOUNT = new QLineEdit(AddAgente);
        CA_AMOUNT->setObjectName(QString::fromUtf8("CA_AMOUNT"));
        CA_AMOUNT->setGeometry(QRect(210, 420, 121, 20));
        lbid = new QLabel(AddAgente);
        lbid->setObjectName(QString::fromUtf8("lbid"));
        lbid->setGeometry(QRect(20, 300, 47, 14));
        LEID = new QLineEdit(AddAgente);
        LEID->setObjectName(QString::fromUtf8("LEID"));
        LEID->setGeometry(QRect(140, 300, 271, 20));
        SW->addWidget(AddAgente);
        ListaACT = new QWidget();
        ListaACT->setObjectName(QString::fromUtf8("ListaACT"));
        title_16 = new QLabel(ListaACT);
        title_16->setObjectName(QString::fromUtf8("title_16"));
        title_16->setGeometry(QRect(160, 20, 441, 71));
        backRP_4 = new QPushButton(ListaACT);
        backRP_4->setObjectName(QString::fromUtf8("backRP_4"));
        backRP_4->setGeometry(QRect(470, 440, 111, 61));
        backRP_4->setFont(font2);
        backRP_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));
        backRP_4->setIcon(icon4);
        lineEdit = new QLineEdit(ListaACT);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(160, 130, 331, 22));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Segoe UI Historic"));
        font3.setPointSize(9);
        lineEdit->setFont(font3);
        checkData = new QCheckBox(ListaACT);
        checkData->setObjectName(QString::fromUtf8("checkData"));
        checkData->setGeometry(QRect(510, 120, 81, 31));
        QFont font4;
        font4.setFamily(QString::fromUtf8("MS Sans Serif"));
        font4.setPointSize(10);
        font4.setBold(true);
        font4.setWeight(75);
        checkData->setFont(font4);
        lineEdit_2 = new QLineEdit(ListaACT);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(160, 280, 331, 22));
        lineEdit_2->setFont(font3);
        lineEdit_3 = new QLineEdit(ListaACT);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(160, 180, 331, 22));
        lineEdit_3->setFont(font3);
        lineEdit_4 = new QLineEdit(ListaACT);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(160, 230, 331, 22));
        lineEdit_4->setFont(font3);
        lineEdit_5 = new QLineEdit(ListaACT);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(160, 330, 331, 22));
        lineEdit_5->setFont(font3);
        lineEdit_6 = new QLineEdit(ListaACT);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(160, 380, 331, 22));
        lineEdit_6->setFont(font3);
        checkFirmar = new QCheckBox(ListaACT);
        checkFirmar->setObjectName(QString::fromUtf8("checkFirmar"));
        checkFirmar->setGeometry(QRect(510, 220, 81, 31));
        checkFirmar->setFont(font4);
        checkEquipo = new QCheckBox(ListaACT);
        checkEquipo->setObjectName(QString::fromUtf8("checkEquipo"));
        checkEquipo->setGeometry(QRect(510, 270, 81, 31));
        checkEquipo->setFont(font4);
        checkPerfil = new QCheckBox(ListaACT);
        checkPerfil->setObjectName(QString::fromUtf8("checkPerfil"));
        checkPerfil->setGeometry(QRect(510, 320, 81, 31));
        checkPerfil->setFont(font4);
        checkExtensiones = new QCheckBox(ListaACT);
        checkExtensiones->setObjectName(QString::fromUtf8("checkExtensiones"));
        checkExtensiones->setGeometry(QRect(510, 370, 81, 31));
        checkExtensiones->setFont(font4);
        checkEntrega = new QCheckBox(ListaACT);
        checkEntrega->setObjectName(QString::fromUtf8("checkEntrega"));
        checkEntrega->setGeometry(QRect(510, 170, 81, 31));
        checkEntrega->setFont(font4);
        saveCh = new QPushButton(ListaACT);
        saveCh->setObjectName(QString::fromUtf8("saveCh"));
        saveCh->setGeometry(QRect(180, 440, 121, 61));
        saveCh->setFont(font2);
        saveCh->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));
        saveCh->setIcon(icon4);
        SW->addWidget(ListaACT);
        VerAG = new QWidget();
        VerAG->setObjectName(QString::fromUtf8("VerAG"));
        title_17 = new QLabel(VerAG);
        title_17->setObjectName(QString::fromUtf8("title_17"));
        title_17->setGeometry(QRect(190, 10, 361, 42));
        verAgents = new QTableWidget(VerAG);
        if (verAgents->columnCount() < 8)
            verAgents->setColumnCount(8);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        verAgents->setHorizontalHeaderItem(7, __qtablewidgetitem7);
        verAgents->setObjectName(QString::fromUtf8("verAgents"));
        verAgents->setGeometry(QRect(20, 70, 731, 401));
        verAgents->setAlternatingRowColors(true);
        verAgents->setGridStyle(Qt::NoPen);
        backVerMed = new QPushButton(VerAG);
        backVerMed->setObjectName(QString::fromUtf8("backVerMed"));
        backVerMed->setGeometry(QRect(660, 10, 61, 41));
        backVerMed->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));
        backVerMed->setIcon(icon4);
        SW->addWidget(VerAG);
        GestionarAG = new QWidget();
        GestionarAG->setObjectName(QString::fromUtf8("GestionarAG"));
        verAG = new QTableWidget(GestionarAG);
        if (verAG->columnCount() < 9)
            verAG->setColumnCount(9);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(0, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(1, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(2, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(3, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(4, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(5, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(6, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(7, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        verAG->setHorizontalHeaderItem(8, __qtablewidgetitem16);
        verAG->setObjectName(QString::fromUtf8("verAG"));
        verAG->setGeometry(QRect(0, 110, 751, 301));
        verAG->setAlternatingRowColors(true);
        verAG->setShowGrid(true);
        title_18 = new QLabel(GestionarAG);
        title_18->setObjectName(QString::fromUtf8("title_18"));
        title_18->setGeometry(QRect(170, 10, 381, 42));
        update_AG = new QPushButton(GestionarAG);
        update_AG->setObjectName(QString::fromUtf8("update_AG"));
        update_AG->setGeometry(QRect(30, 440, 161, 41));
        back_m = new QPushButton(GestionarAG);
        back_m->setObjectName(QString::fromUtf8("back_m"));
        back_m->setGeometry(QRect(620, 20, 101, 41));
        back_m->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(255,255,255);\n"
"color:rgb(62,95,138);\n"
"}"));
        back_m->setIcon(icon4);
        addAG = new QPushButton(GestionarAG);
        addAG->setObjectName(QString::fromUtf8("addAG"));
        addAG->setGeometry(QRect(210, 440, 161, 41));
        eliminarAG = new QPushButton(GestionarAG);
        eliminarAG->setObjectName(QString::fromUtf8("eliminarAG"));
        eliminarAG->setGeometry(QRect(390, 440, 161, 41));
        Lista_act = new QPushButton(GestionarAG);
        Lista_act->setObjectName(QString::fromUtf8("Lista_act"));
        Lista_act->setGeometry(QRect(570, 440, 151, 41));
        Lista_act->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"background-color: rgb(62,95,138);\n"
"color:rgb(255,255,255);\n"
"}"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/imgs/paciente.png"), QSize(), QIcon::Normal, QIcon::On);
        Lista_act->setIcon(icon7);
        eliminarAG_2 = new QPushButton(GestionarAG);
        eliminarAG_2->setObjectName(QString::fromUtf8("eliminarAG_2"));
        eliminarAG_2->setGeometry(QRect(390, 440, 161, 41));
        SW->addWidget(GestionarAG);

        gridLayout->addWidget(SW, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        SW->setCurrentIndex(4);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "LOGIN", nullptr));
        aceptar_PB->setText(QCoreApplication::translate("MainWindow", "Aceptar", nullptr));
        usuario_LB->setText(QCoreApplication::translate("MainWindow", "Usuario", nullptr));
        contrasena_LB->setText(QCoreApplication::translate("MainWindow", "Contrase\303\261a", nullptr));
        contrasena_LE->setInputMask(QString());
        cancelar_PB->setText(QCoreApplication::translate("MainWindow", "Cancelar", nullptr));
        label_4->setText(QString());
        Iniciar->setText(QCoreApplication::translate("MainWindow", "INICIAR", nullptr));
        title->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; font-weight:600; text-decoration: underline; color:#55557f;\">TP Link</span></p><p align=\"center\"><span style=\" font-size:14pt; text-decoration: underline;\"><br/></span></p></body></html>", nullptr));
        NameUser->setText(QString());
        AddAgent->setText(QCoreApplication::translate("MainWindow", "A\303\261adir a agente WAHA", nullptr));
        VerLista->setText(QCoreApplication::translate("MainWindow", "Ver Lista de WAHA staff", nullptr));
        logOut->setText(QCoreApplication::translate("MainWindow", "Cerrar Sesi\303\263n", nullptr));
        img_2->setText(QString());
        title_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600; color:#55557f;\">Welcome</span></p></body></html>", nullptr));
        Gestionar->setText(QCoreApplication::translate("MainWindow", "Gestionar WAHA staff", nullptr));
        namesAG->setText(QCoreApplication::translate("MainWindow", "Nombre/s:", nullptr));
        lastnameAG->setText(QCoreApplication::translate("MainWindow", "Apellidos:", nullptr));
        sexAG_2->setText(QCoreApplication::translate("MainWindow", "Sexo:", nullptr));
        Fecha_nacAG->setText(QCoreApplication::translate("MainWindow", "Fecha de Nacimiento:", nullptr));
        curpAG->setText(QCoreApplication::translate("MainWindow", "CURP:", nullptr));
        rfcAG->setText(QCoreApplication::translate("MainWindow", "RFC:", nullptr));
        addressAG->setText(QCoreApplication::translate("MainWindow", "Direcci\303\263n:", nullptr));
        celAG->setText(QCoreApplication::translate("MainWindow", "N\303\272mero de cel:", nullptr));
        lastnameAG1->setPlaceholderText(QCoreApplication::translate("MainWindow", "Apellido Paterno", nullptr));
        sexAG->setPlaceholderText(QCoreApplication::translate("MainWindow", "M / F", nullptr));
        Fecha_nacAG_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "YYYY-MM-DD", nullptr));
        curpAG_2->setPlaceholderText(QString());
        addressAG_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "Ejemplo: 2021 San Pablo", nullptr));
        celAG_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "10 d\303\255gitos", nullptr));
        hiredDL->setText(QCoreApplication::translate("MainWindow", "Equipo info:", nullptr));
        saveAG->setText(QCoreApplication::translate("MainWindow", "Guardar Registro", nullptr));
        backMenu->setText(QCoreApplication::translate("MainWindow", "Regresar", nullptr));
        lastnameAG2->setPlaceholderText(QCoreApplication::translate("MainWindow", "Apellido Materno", nullptr));
        title_6->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600; color:#55557f;\">Agente</span></p></body></html>", nullptr));
        UpdateAG->setText(QCoreApplication::translate("MainWindow", "Modificar", nullptr));
        CancelarADD->setText(QCoreApplication::translate("MainWindow", "Cancelar", nullptr));
        SearchAG->setText(QCoreApplication::translate("MainWindow", "Buscar Agente:", nullptr));
        SearchAG_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        SearchAG_3->setText(QCoreApplication::translate("MainWindow", "Buscar", nullptr));
        monitorSN_1->setPlaceholderText(QString());
        cpuSN_2->setPlaceholderText(QString());
        monitorSN->setText(QCoreApplication::translate("MainWindow", "Monitores N\303\272mero de series:", nullptr));
        cpuSN->setText(QCoreApplication::translate("MainWindow", "CPU N\303\272mero de serie:", nullptr));
        CableRedCB->setText(QCoreApplication::translate("MainWindow", "Cantidad de Cables:", nullptr));
        lbmonitor1->setText(QCoreApplication::translate("MainWindow", "#1", nullptr));
        lbmonitor2->setText(QCoreApplication::translate("MainWindow", "#2", nullptr));
        lbid->setText(QCoreApplication::translate("MainWindow", "ID:", nullptr));
        title_16->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:26pt; font-weight:600; color:#55557f;\">Lista de Actividades</span></p></body></html>", nullptr));
        backRP_4->setText(QCoreApplication::translate("MainWindow", "Regresar", nullptr));
        lineEdit->setText(QCoreApplication::translate("MainWindow", "Ingresar la informacion personal del agente", nullptr));
        checkData->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        lineEdit_2->setText(QCoreApplication::translate("MainWindow", "Ingresar la informacion del equipo del agente", nullptr));
        lineEdit_3->setText(QCoreApplication::translate("MainWindow", "Entrega de equipo al agente WAHA", nullptr));
        lineEdit_4->setText(QCoreApplication::translate("MainWindow", "Firma de responsiva por los equipos entregados", nullptr));
        lineEdit_5->setText(QCoreApplication::translate("MainWindow", "Peticion de cambio de perfil a waha (RH)", nullptr));
        lineEdit_6->setText(QCoreApplication::translate("MainWindow", "Asignacion de extensiones para tomar llamadas ", nullptr));
        checkFirmar->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        checkEquipo->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        checkPerfil->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        checkExtensiones->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        checkEntrega->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        saveCh->setText(QCoreApplication::translate("MainWindow", "Guardar Cambios", nullptr));
        title_17->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600; color:#55557f;\">Agentes</span></p></body></html>", nullptr));
        QTableWidgetItem *___qtablewidgetitem = verAgents->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "Nombre/s", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = verAgents->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "Apellido P.", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = verAgents->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "Apellido M.", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = verAgents->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "Fecha Nac.", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = verAgents->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "Curp", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = verAgents->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "RFC", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = verAgents->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "Direcci\303\263n", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = verAgents->horizontalHeaderItem(7);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("MainWindow", "Celular", nullptr));
        backVerMed->setText(QCoreApplication::translate("MainWindow", "Regresar", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = verAG->horizontalHeaderItem(0);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = verAG->horizontalHeaderItem(1);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("MainWindow", "Nombre", nullptr));
        QTableWidgetItem *___qtablewidgetitem10 = verAG->horizontalHeaderItem(2);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("MainWindow", "Apellido Paterno", nullptr));
        QTableWidgetItem *___qtablewidgetitem11 = verAG->horizontalHeaderItem(3);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("MainWindow", "Apellido Materno", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = verAG->horizontalHeaderItem(4);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("MainWindow", "Fecha Nac.", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = verAG->horizontalHeaderItem(5);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("MainWindow", "CURP", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = verAG->horizontalHeaderItem(6);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("MainWindow", "RFC", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = verAG->horizontalHeaderItem(7);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("MainWindow", "Domicilio", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = verAG->horizontalHeaderItem(8);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("MainWindow", "Celular", nullptr));
        title_18->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:20pt; font-weight:600; color:#55557f;\">Agentes</span></p></body></html>", nullptr));
        update_AG->setText(QCoreApplication::translate("MainWindow", "Modificar Agente", nullptr));
        back_m->setText(QCoreApplication::translate("MainWindow", "Regresar", nullptr));
        addAG->setText(QCoreApplication::translate("MainWindow", "A\303\261adir Agente", nullptr));
        eliminarAG->setText(QCoreApplication::translate("MainWindow", "Eliminar agente", nullptr));
        Lista_act->setText(QCoreApplication::translate("MainWindow", "Lista de Actividades", nullptr));
        eliminarAG_2->setText(QCoreApplication::translate("MainWindow", "Eliminar agente", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
