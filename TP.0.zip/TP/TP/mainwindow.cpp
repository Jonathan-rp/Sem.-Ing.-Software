#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    TP = QSqlDatabase:: addDatabase("QSQLITE");
    QString ubicacion= ("TP.db");
    TP.setDatabaseName(ubicacion);
    TP.open();

    if(!TP.open()){
        qDebug()<<"No se abrio esta wea";
    }else{
        qDebug()<<"Si se abrió la base de Datos";
    }

    ui->SW->setCurrentIndex(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_Iniciar_clicked()
{
        ui->SW->setCurrentIndex(2);
}

void MainWindow::on_aceptar_PB_clicked()
{
    QMessageBox message;
    QString usuario, contrasena, query, name,rol;

    usuario = ui->usuario_LE->text();
    contrasena = ui->contrasena_LE->text();

     QSqlQuery qry;

     query.append("SELECT * FROM ADMIN WHERE USER = '"+usuario+"' AND PASSWORD = '"+contrasena+"'");
     qry.prepare(query);

     if(qry.exec()){
         qDebug()<<"Se ha consultado correctamente";
         message.setText("WELCOME :)");
         message.exec();
         ui->SW->setCurrentIndex(1);
         ui->usuario_LE->setText("");
         ui->contrasena_LE->setText("");
         qry.next();
         name = qry.value(3).toByteArray().constData();
         rol = qry.value(5).toByteArray().constData();
         ui->NameUser->setText("WELCOME "+rol+" "+name);
     }
     else{
         qDebug()<<"User not found";
         qDebug()<<"ERROR! "<<qry.lastError();
         message.setText("USER OR PASSWORD ARE INCORRECT :c");
         message.exec();
         ui->usuario_LE->setText("");
         ui->contrasena_LE->setText("");
     }

}

void MainWindow::on_cancelar_PB_clicked()
{
    exit(0);
}

void MainWindow::on_AddAgent_clicked()
{
    ui->SW->setCurrentIndex(3);
}

void MainWindow::on_Lista_act_clicked()
{
    ui->SW->setCurrentIndex(4);
}

void MainWindow::on_VerLista_clicked()
{
    ui->SW->setCurrentIndex(5);
}

void MainWindow::on_Gestionar_clicked()
{
    ui->SW->setCurrentIndex(6);
}

void MainWindow::on_logOut_clicked()
{
    ui->SW->setCurrentIndex(0);
}

void MainWindow::on_backMenu_clicked()
{
    ui->SW->setCurrentIndex(2);
}

void MainWindow::on_backRP_4_clicked()
{
    ui->SW->setCurrentIndex(2);
}

void MainWindow::on_backVerMed_clicked()
{
    ui->SW->setCurrentIndex(2);
}

void MainWindow::on_back_m_clicked()
{
    ui->SW->setCurrentIndex(2);
}
