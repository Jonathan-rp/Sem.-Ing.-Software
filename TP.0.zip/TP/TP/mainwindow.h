#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>
#include <QtSql>
#include <QtDebug>
#include <QFileInfo>
#include <QString>
#include <windows.h>
#include <stdio.h>
#include <QMessageBox>
#include <iostream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <time.h>

using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_Iniciar_clicked();

    void on_aceptar_PB_clicked();

    void on_cancelar_PB_clicked();

    void on_AddAgent_clicked();

    void on_Lista_act_clicked();

    void on_VerLista_clicked();

    void on_Gestionar_clicked();

    void on_logOut_clicked();

    void on_backMenu_clicked();

    void on_backRP_4_clicked();

    void on_backVerMed_clicked();

    void on_back_m_clicked();

private:
    Ui::MainWindow *ui;
    QSqlDatabase TP;
};
#endif // MAINWINDOW_H
